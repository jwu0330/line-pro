// Background service worker for Open LINE in Edge extension
// Popup 會直接觸發協定，這裡只是保持 service worker 活躍

console.log('[LINE Extension] Background service worker loaded');
